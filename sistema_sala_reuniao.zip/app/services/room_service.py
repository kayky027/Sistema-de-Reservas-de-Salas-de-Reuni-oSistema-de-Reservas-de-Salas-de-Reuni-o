
class RoomService:
    def __init__(self, rooms_collection):
        self.rooms = rooms_collection

    def create_room(self, name, capacity, resources, is_active=True):
        room = {
            "name": name,
            "capacity": capacity,
            "resources": resources,
            "is_active": is_active
        }
        self.rooms.insert_one(room)
        return room

    def get_all_rooms(self):
        return list(self.rooms.find())

    def update_room(self, room_id, updates):
        self.rooms.update_one({"_id": room_id}, {"$set": updates})

    def delete_room(self, room_id):
        self.rooms.delete_one({"_id": room_id})
