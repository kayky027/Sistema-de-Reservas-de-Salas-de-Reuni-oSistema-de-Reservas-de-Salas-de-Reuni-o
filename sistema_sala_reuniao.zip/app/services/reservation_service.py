
from datetime import datetime

class ReservationService:
    def __init__(self, reservations_collection, rooms_collection):
        self.reservations = reservations_collection
        self.rooms = rooms_collection

    def create_reservation(self, room_id, user_id, start_time, end_time):
        # Validate room availability
        overlapping = self.reservations.find_one({
            "room_id": room_id,
            "$or": [
                {"start_time": {"$lt": end_time, "$gte": start_time}},
                {"end_time": {"$gt": start_time, "$lte": end_time}}
            ]
        })
        if overlapping:
            raise Exception("Room is not available at this time.")

        # Validate room status
        room = self.rooms.find_one({"_id": room_id})
        if not room["is_active"]:
            raise Exception("Room is deactivated.")

        reservation = {
            "room_id": room_id,
            "user_id": user_id,
            "start_time": start_time,
            "end_time": end_time
        }
        self.reservations.insert_one(reservation)
        return reservation

    def get_user_reservations(self, user_id):
        return list(self.reservations.find({"user_id": user_id}))
